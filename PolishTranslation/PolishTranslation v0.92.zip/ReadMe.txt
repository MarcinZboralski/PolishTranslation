PolishTranslation v0.92 Initial Version
-All in-game text has been translated outside of KSPedia

Known Issues: 
-The syntax of some sentences may not make sense

Installation
1.Unpack GameData to main folder
2.Run Game 